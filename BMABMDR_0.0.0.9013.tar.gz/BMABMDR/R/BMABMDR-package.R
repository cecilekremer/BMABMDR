#' The 'BMABMDR' package.
#'
#' @description A DESCRIPTION OF THE PACKAGE
#'
#' @docType package
#' @name BMABMDR-package
#' @aliases BMABMDR
#' @useDynLib BMABMDR, .registration = TRUE
#' @import methods
#' @import Rcpp
#' @import truncnorm
#' @importFrom rstan sampling
#'
#' @references
#' Stan Development Team (NA). RStan: the R interface to Stan. R package version 2.26.3. https://mc-stan.org
#'
NULL
