#' The BMABMD package
#'
#' Here comes the information of the package
#'
#' Some more information
#'
#' @docType package
#'
#' @import ggplot2 forcats mvtnorm mc2d ggpubr RColorBrewer posterior bbmle AICcmodavg numDeriv bridgesampling rstan gamlss rstantools truncnorm
NULL
