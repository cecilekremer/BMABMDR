# EFSA Bayesian Benchmark Dose Response Platform

R package for bayesian model averaging in benchmark dose estimation


